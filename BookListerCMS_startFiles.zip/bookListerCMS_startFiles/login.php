<?php
    
if (!session_id()) {
    session_start();
}

require 'sanitize.php';
// Save any value in $_GET['url'] that was passed into this in a session
// variable we will call targetURL





// If the login form has been submitted, try to authenticate
// the user based on our DB users table
//
$clickIt = sanitizeString(INPUT_POST, 'clickIt');

if (isset($clickIt)) {
    
    // process the form data
    
    // acquire the username and password from the form
    
    
    //echo "<h2>\$uName = $uName *** \$pWord = $pWord</h2>";
    
    if ($uName == "" || $pWord == "") {
        echo "<h3 style=\"color:red\">Please enter both a username and password</h3>\n";
    } else {
        
        require 'dbConnect.php';
        require 'callQuery.php';
        
        
        
    }
    
} else {  // login form not submitted
    
    $logOut = sanitizeString(INPUT_GET, 'logOut');
    
    // check if user wishes to log out
    
    
}

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>BookLister CMS Admin Login Page</title>
    </head>
    <body>
        <h2 id="myh2">Please login to gain administrative access</h2>
        
        <form action="" method="post">
            <label for="userName">Username:</label>
            <input type="text" placeholder="Username" name="userName" id="userName">
            <br><br>
            
            <label for="passWord">Password:</label>
            <input type="password" placeholder="Password" name="passWord" id="passWord">
            <br><br>
            
            <input type="submit" name="clickIt" value="Log In">
        </form>
    </body>
</html>
