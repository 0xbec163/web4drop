<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Create CMS Admin Accounts</title>
    </head>
    <body>
        <?php
        ini_set('display_errors', 1);
        error_reporting(-1);
        
        
        // Connect to our DB server and select our DB
        require 'dbConnect.php';
        
        // Drop any existing users table
        try {
            
        } catch (PDOException $ex) {
            $error = 'Could not drop table';
            include 'error.html.php';
            throw $ex;
            // exit();
        }
        
        //
        // (Re)create the users table
        //
        try {
            
            
            
        } catch (PDOException $ex) {
            $error = 'Could not create table';
            include 'error.html.php';
            throw $ex;
            // exit();
        }
        
        //
        // Get user information from the ids_sp2018.txt file and 
        // insert generated account information into users table
        //
        
                
                // Break up line into two fields
                
                
                // Construct the username and password
                //
                // username = first character of first name
                // followed by the last name.
                
                
                // password = 
                // first 4 chars of last name if present,
                // followed by the length of last name, 
                // followed by first name with an uppercase first letter.
                
                
                //echo "<h2 style=\"color:green\">Username: $userName <br> password: $pWord <br> md5: $md5password <br> sha1: $sha1password<br> 1st new hash: $hashedPassword<br> 2nd new hash: $anotherHashedPassword</h2>";
                
                // 
                // Insert our account data into the users table
                //
                
        
        ?>
    </body>
</html>
