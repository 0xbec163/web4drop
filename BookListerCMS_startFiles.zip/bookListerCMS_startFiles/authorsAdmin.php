<?php
if (!session_id()) {
    session_start();
}

require 'authenticate.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>CMS - Authors Admin Page</title>
        
        <link href="css/authorsAdmin.css" rel="stylesheet">
    </head>
    <body>
        <h2>Manage Authors</h2>
        <?php
          
        require 'dbConnect.php';
        require 'callQuery.php';
        
        // Query our DB and get all author information
        
        

        ?>
        <table>
            
        <?php
        // Step through the result set (PDOStatement object) one
        // row at a time
        
        
        
        
        ?>
            
        </table>
    </body>
</html>
