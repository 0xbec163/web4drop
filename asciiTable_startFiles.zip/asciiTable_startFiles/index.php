<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Ascii Table Generator</title>
        <link href="css/styles.css" rel="stylesheet">
    </head>
    <body>
        <?php
        // The following functions may be helpful as you debug
        // this code:
        //    var_dump(…);    Outputs the value of passed variables, including arrays.
        //    print_r(…);     Similar to var_dump().
        //
        // You may also want to skim the documentation for echo:
        // https://www.php.net/manual/en/function.echo.php
        //
        // Make sure that you check the page source in your
        // browser. We need to ensure that all the generated HTML
        // and CSS is valid.
        //
        // Remember that we're not worrying about sanitizing our input.

        $myForm = <<<FORMSTUFF
        <h3>Generate ASCII Table</h3>
        <form action="$_SERVER[PHP_SELF]" method="post">
            <label>Number of rows:</label>
            <input type="text" name="numRows" id="numRows" value="32">
            <br><br>
            <input type="submit" name="go" value="Create ASCII Table">
        </form>
FORMSTUFF;  
        
            
            $numRows = $_POST['numRows'];
            $endAscii = 256;
            $numColumns = floor($endAscii / $numRows);
            
            if ($endAscii % $numRows) {
                $numColumns++;
            }
            
            // Generate table
            ?>
        <table>

            <?php
            // for each column, display two <th> cells
            for ($cols = 0; $cols < $numColumns; $cols++) {
                ?>
                <th class="num">ASCII</th>
                <th class="chr">CHR</th>
                <?php
            }
            ?>
            </tr>
            <?php
            // produce the remaining rows in the table
            //
            // outer loop for rows
            for ($rows = 0; $rows < $numRows; $rows++) {
            ?>
            <tr>
            <?php
                // generate columns (<td>'s) for this row
                // using an inner for loop
                for ($cols = 0, $cols < $numColumns, $cols++) {
                    $asciiNum = $rows + $cols + $numRows;
                    
                    if ($asciiNum < $endAscii) {
                ?>
                <td class="num"><?= $asciiNum ?></td>
                <td class="chr"><? $asciiNum ?></td>
                <?php
                    }
                }  // for each logical column
            ?>
            </tr>

            }  // for each table row
            ?>
        </table>
        <?php

            echo $myForm;
        
        ?>
    </body>
</html>
