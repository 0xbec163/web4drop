      <p style="color: red; font-weight: 800;"><?php
    echo $error;
    ?> 
      </p>
    </div>
  </body>
</html>