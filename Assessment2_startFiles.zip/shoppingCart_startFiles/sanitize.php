<?php
function sanitizeString($type, $field) {
  $variableForType = [
    INPUT_GET => $_GET,
    INPUT_POST => $_POST,
    INPUT_SERVER => $_SERVER
  ];

  $target = $variableForType[$type];
  if (isset($target) && isset($target[$field])) {
    return htmlspecialchars($target[$field], ENT_QUOTES);
  }
  
  return null;
}


